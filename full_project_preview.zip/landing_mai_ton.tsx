// src/pages/uu-dai/mai-ton.tsx
import Head from 'next/head';
import Image from 'next/image';
import LeadForm from '@/components/LeadForm';

export default function LandingMaiTon() {
  return (
    <div className="bg-white">
      <Head>
        <title>Mái tôn lấy sáng - Ưu đãi lắp đặt tháng này</title>
        <meta name="description" content="Thi công mái tôn lấy sáng chống nóng, lấy sáng tự nhiên, độ bền cao. Báo giá minh bạch, lắp đặt nhanh chóng." />
        <meta name="robots" content="noindex, nofollow" />
      </Head>

      <section className="min-h-screen flex flex-col items-center justify-center px-4 py-20">
        <div className="max-w-3xl text-center">
          <h1 className="text-3xl md:text-5xl font-bold text-gray-800 mb-6 leading-tight">
            Mái tôn lấy sáng thông minh – Giải pháp chống nóng & tiết kiệm điện
          </h1>
          <p className="text-gray-600 text-lg mb-4">
            Thiết kế đa dạng • Bền đẹp • Thi công nhanh • Bảo hành lâu dài
          </p>
          <p className="text-gray-700 mb-6">Đăng ký tư vấn hôm nay để nhận ưu đãi đặc biệt trong tháng.</p>

          <div className="relative w-full h-64 md:h-96 mb-10">
            <Image
              src="/images/sp-mai-ton.jpg"
              alt="Mái tôn lấy sáng hiện đại"
              fill
              className="object-cover rounded-lg shadow-lg"
            />
          </div>

          <div className="max-w-md mx-auto">
            <LeadForm />
          </div>
        </div>
      </section>
    </div>
  );
}