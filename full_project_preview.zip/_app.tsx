// src/pages/_app.tsx
import '@/styles/globals.css';
import type { AppProps } from 'next/app';
import Script from 'next/script';
import Head from 'next/head';
import { useEffect, useState } from 'react';

export default function App({ Component, pageProps }: AppProps) {
  const [isMobile, setIsMobile] = useState(false);
  const [showExitPopup, setShowExitPopup] = useState(false);

  useEffect(() => {
    setIsMobile(typeof window !== 'undefined' && window.innerWidth < 768);

    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const utm_source = urlParams.get('utm_source');
      const utm_medium = urlParams.get('utm_medium');
      const utm_campaign = urlParams.get('utm_campaign');
      const gclid = urlParams.get('gclid');

      if (utm_source || utm_medium || utm_campaign || gclid) {
        window.localStorage.setItem('source_tracking', JSON.stringify({
          utm_source, utm_medium, utm_campaign, gclid
        }));
      }

      // Gắn tracking click vào Zalo chat
      setTimeout(() => {
        const zaloWidget = document.querySelector('.zalo-chat-widget');
        if (zaloWidget) {
          zaloWidget.addEventListener('click', () => {
            const sourceData = localStorage.getItem('source_tracking');
            const parsed = sourceData ? JSON.parse(sourceData) : {};
            if (window.gtag) {
              window.gtag('event', 'click_zalo_chat', {
                event_category: 'engagement',
                event_label: 'zalo_widget',
                value: 1,
                ...parsed
              });
            }
            if (window.fbq) {
              window.fbq('trackCustom', 'ClickZaloChat', parsed);
            }
          });
        }
      }, 2000);

      // Exit intent detection
      const handleMouseLeave = (e: MouseEvent) => {
        if (e.clientY < 10 && !showExitPopup) {
          setShowExitPopup(true);
          const sourceData = localStorage.getItem('source_tracking');
          const parsed = sourceData ? JSON.parse(sourceData) : {};
          if (window.gtag) {
            window.gtag('event', 'exit_popup_shown', {
              event_category: 'engagement',
              event_label: 'popup_exit_intent',
              ...parsed
            });
          }
          if (window.fbq) {
            window.fbq('trackCustom', 'ExitIntentPopup', parsed);
          }
        }
      };
      document.addEventListener('mouseout', handleMouseLeave);
      return () => document.removeEventListener('mouseout', handleMouseLeave);
    }
  }, [showExitPopup]);

  const trackCallClick = () => {
    const sourceData = typeof window !== 'undefined' ? window.localStorage.getItem('source_tracking') : null;
    const parsedSource = sourceData ? JSON.parse(sourceData) : {};

    if (typeof window !== 'undefined') {
      if (window.gtag) {
        window.gtag('event', 'click_to_call', {
          event_category: 'cta',
          event_label: 'call_button_footer',
          value: 1,
          ...parsedSource
        });
      }
      if (window.fbq) {
        window.fbq('trackCustom', 'ClickToCall', parsedSource);
      }
    }
  };

  return (
    <>
      <Head>{/* ... giữ nguyên nội dung cũ ... */}</Head>

      {/* ... giữ nguyên các Script và tiện ích khác ... */}

      {isMobile && (
        <a
          href="tel:0976830180"
          onClick={trackCallClick}
          className="fixed bottom-20 right-6 animate-bounce bg-red-600 text-white px-5 py-3 rounded-full shadow-xl z-50 text-base font-semibold hover:bg-red-700"
        >
          📞 Gọi ngay: 0976 830 180
        </a>
      )}

      {showExitPopup && (
        <div className="fixed inset-0 z-[999] bg-black bg-opacity-60 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full text-center shadow-2xl border border-red-100 animate-fade-in">
            <h3 className="text-2xl font-bold text-red-600 mb-3">🎁 Ưu đãi dành riêng cho bạn</h3>
            <p className="text-gray-700 mb-4 text-sm">Đăng ký tư vấn ngay hôm nay để được <strong>tặng thêm gói bảo trì miễn phí</strong> và ưu đãi đặc biệt chỉ trong tháng này!</p>
            <a
              href="https://zalo.me/0976830180"
              target="_blank"
              className="inline-block bg-red-600 text-white font-semibold text-sm px-5 py-2 rounded-full hover:bg-red-700 shadow-md"
            >
              💬 Nhận tư vấn ngay
            </a>
            <button onClick={() => setShowExitPopup(false)} className="block mx-auto mt-4 text-xs text-gray-500 underline hover:text-gray-700">
              Không, cảm ơn
            </button>
          </div>
        </div>
      )}

      <Component {...pageProps} />
    </>
  );
}
